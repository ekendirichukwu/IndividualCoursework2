let mySub =[

    {
        "id": 1001,
        "title": "Math",
        "location":"London",
        "price": 150,
        "image": "/math.jpg",
        "availableInventory": 1
       
      }, 
      {
        "id": 1002,
        "title": "English",
        "location":"Chelsea",
        "price": 150,
        "image": "eng.jpg",
        "availableInventory": 15
       
      }, 
      {
        "id": 1003,
        "title": "Physics",
        "location":"Oxford",
        "price": 80,
        "image": "phy.jpg",
        "availableInventory": 5
       
      }, 
      {
        "id": 1004,
        "title": "Music",
        "location":"New York",
        "price": 100,
        "image": "music.jpg",
        "availableInventory": 5
       
      }, 
      {
        "id": 1005,
        "title": "Web App",
        "location":"Dubai",
        "price": 150,
        "image": "web.jpg",
        "availableInventory": 15
       
      }, 
      {
        "id": 1006,
        "title": "UI/UX",
        "location":"Sharjah",
        "price": 90,
        "image": "ui.jpg",
        "availableInventory": 10
       
      }, 
      {
        "id": 1007,
        "title": "Math",
        "location":"Dubai",
        "price": 90,
        "image": "math.jpg",
        "availableInventory": 6
       
      }, 
      {
        "id": 1008,
        "title": "English",
        "location":"Doha",
        "price": 85,
        "image": "eng.jpg",
        "availableInventory": 15
       
      }, 
      {
        "id": 1009,
        "title": "Web App",
        "location":"London",
        "price": 100,
        "image": "web.jpg",
        "availableInventory": 5
       
      }, 
      {
        "id": 1010,
        "title": "Economics",
        "location":"New York",
        "price": 100,
        "image": "econs.jpg",
        "availableInventory": 10
       
      }, 
]